package com.example.retrofit_example;

import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.HeaderMap;
import retrofit2.http.Headers;
import retrofit2.http.PATCH;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;
import retrofit2.http.Query;
import retrofit2.http.QueryMap;

public interface JSONPlaceHolder {
    @GET("posts")
    Call<List<Posts>> getPosts();

    @GET("/posts/{id}/comments")
    Call<List<Comment>> getComments(@Path("id") int postid);

    @GET("comments")
    Call<List<Comment>> getQueryComments(@Query("postId") int postId);

    @GET("comments")
    Call<List<Comment>> getMultiQueryComments(
            @Query("postId") int postId,
            @Query("_sort") String id,
            @Query("_order") String order
    );

    @GET("comments")
    Call<List<Comment>> getMultiQueryWithMultiUserComments(
            @Query("postId") Integer[] postId,
            @Query("_sort") String id,
            @Query("_order") String order
    );

    @GET("comments")
    Call<List<Comment>> getCommentsUsingQueryMap(
            @QueryMap Map<String,String> parameters
    );

    @POST("posts")
    Call<Posts> createPost(@Body Posts posts);

    @Headers({"Static-Head:123"})   // Static Headers
    @PUT("posts/{id}")
    Call<Posts> putPost(@HeaderMap Map<String,String> header, @Path("id") int id, @Body Posts posts);

    @PATCH("posts/{id}")
    Call<Posts> patchPost(@Path("id") int id,@Body Posts posts);

    @DELETE("posts/{id}")
    Call<Void> deletePost(@Path("id") int id);
}
