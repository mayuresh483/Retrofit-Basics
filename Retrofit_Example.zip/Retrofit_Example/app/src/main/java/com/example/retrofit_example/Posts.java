package com.example.retrofit_example;

import com.google.gson.annotations.SerializedName;

public class Posts {
    public int getUserId() {
        return userId;
    }

    public int getId() {
        return id;
    }

    public Posts(int userId, String title, String text) {
        this.userId = userId;
        this.title = title;
        this.text = text;
    }

    public String getTitle() {
        return title;
    }

    public String getText() {
        return text;
    }

    private int userId;
    private int id;
    private String title;

    @SerializedName("body")
    private String text;

}
