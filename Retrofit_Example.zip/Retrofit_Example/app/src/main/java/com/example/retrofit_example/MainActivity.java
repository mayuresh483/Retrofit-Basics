package com.example.retrofit_example;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {

    private TextView results;
    private JSONPlaceHolder jsonPlaceHolder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        results = findViewById(R.id.results);

        HttpLoggingInterceptor httpLoggingInterceptor = new HttpLoggingInterceptor();
        httpLoggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);

        OkHttpClient okHttpClient = new OkHttpClient.Builder()
                .addInterceptor(httpLoggingInterceptor)
                .build();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://jsonplaceholder.typicode.com/")
                .addConverterFactory(GsonConverterFactory.create())
                .client(okHttpClient)
                .build();

        jsonPlaceHolder = retrofit.create(JSONPlaceHolder.class);
        // Get All Data
//         getAllData();

        // Get Comment Data w.r.t to post id
//        getComments();

        // Get Data w.r.t to query passed post id
//        getDataWRTQuery();

        // Get Data w.r.t to multi query passed post id
//        getDataWRTMultiQuery();

        // Get Data w.r.t to multi query passed with multi post id
//        getDataWRTMultiQueryMultiUsers();

        // Get Data using QueryMap
//        getDataWRTQueryMap();

        // Create new POST
//        createPost();

        // Put or update post Data
        putPost();

        // Patch or update specific post Data
//        patchPost();

        // Delete specific Post
//        deletePost();
    }

    private void getAllData(){
        Call<List<Posts>> call = jsonPlaceHolder.getPosts();
        call.enqueue(new Callback<List<Posts>>() {
            @Override
            public void onResponse(Call<List<Posts>> call, Response<List<Posts>> response) {
                if(!response.isSuccessful()){
                    results.setText("Unable to get the Data");
                }

                List<Posts> pos1 = response.body();

                for(Posts posts: pos1){
                    String data = "";
                    data+="ID: "+posts.getId()+"\n"+
                            "UserID: "+posts.getUserId()+"\n"+
                            "Title: "+posts.getTitle()+"\n"+
                            "Message:"+posts.getText()+"\n\n";
                    results.append(data);
                }

            }

            @Override
            public void onFailure(Call<List<Posts>> call, Throwable t) {
                results.setText(t.getMessage());
            }
        });
    }

    private void getComments(){
        Call<List<Comment>> call = jsonPlaceHolder.getComments(1);

        call.enqueue(new Callback<List<Comment>>() {
            @Override
            public void onResponse(Call<List<Comment>> call, Response<List<Comment>> response) {
                if(!response.isSuccessful()){
                    results.setText("Unable to get the Data");
                }

                List<Comment> pos1 = response.body();

                for(Comment posts: pos1){
                    String data = "";
                    data+="ID: "+posts.getId()+"\n"+
                            "postID: "+posts.getPostId()+"\n"+
                            "Email: "+posts.getEmail()+"\n"+
                            "Message:"+posts.getMessage()+"\n\n"+
                            "name:"+posts.getName()+"\n\n";
                    results.append(data);
                }
            }

            @Override
            public void onFailure(Call<List<Comment>> call, Throwable t) {
                results.setText(t.getMessage());
            }
        });
    }

    private void getDataWRTQuery(){
        Call<List<Comment>> call = jsonPlaceHolder.getQueryComments(9);

        call.enqueue(new Callback<List<Comment>>() {
            @Override
            public void onResponse(Call<List<Comment>> call, Response<List<Comment>> response) {
                if(!response.isSuccessful()){
                    results.setText("Unable to get the Data");
                }

                List<Comment> pos1 = response.body();

                for(Comment posts: pos1){
                    String data = "";
                    data+="ID: "+posts.getId()+"\n"+
                            "postID: "+posts.getPostId()+"\n"+
                            "Email: "+posts.getEmail()+"\n"+
                            "Message:"+posts.getMessage()+"\n\n"+
                            "name:"+posts.getName()+"\n\n";
                    results.append(data);
                }
            }

            @Override
            public void onFailure(Call<List<Comment>> call, Throwable t) {
                results.setText(t.getMessage());
            }
        });
    }

    private void getDataWRTMultiQuery(){
        Call<List<Comment>> call = jsonPlaceHolder.getMultiQueryComments(6,"id","Desc");

        call.enqueue(new Callback<List<Comment>>() {
            @Override
            public void onResponse(Call<List<Comment>> call, Response<List<Comment>> response) {
                if(!response.isSuccessful()){
                    results.setText("Unable to get the Data");
                }

                List<Comment> pos1 = response.body();

                for(Comment posts: pos1){
                    String data = "";
                    data+="ID: "+posts.getId()+"\n"+
                            "postID: "+posts.getPostId()+"\n"+
                            "Email: "+posts.getEmail()+"\n"+
                            "Message:"+posts.getMessage()+"\n\n"+
                            "name:"+posts.getName()+"\n\n";
                    results.append(data);
                }
            }

            @Override
            public void onFailure(Call<List<Comment>> call, Throwable t) {
                results.setText(t.getMessage());
            }
        });
    }

    private void getDataWRTMultiQueryMultiUsers(){
        Call<List<Comment>> call = jsonPlaceHolder.getMultiQueryWithMultiUserComments(new Integer[]{1,5,3},"id","Desc");

        call.enqueue(new Callback<List<Comment>>() {
            @Override
            public void onResponse(Call<List<Comment>> call, Response<List<Comment>> response) {
                if(!response.isSuccessful()){
                    results.setText("Unable to get the Data");
                }

                List<Comment> pos1 = response.body();

                for(Comment posts: pos1){
                    String data = "";
                    data+="ID: "+posts.getId()+"\n"+
                            "postID: "+posts.getPostId()+"\n"+
                            "Email: "+posts.getEmail()+"\n"+
                            "Message:"+posts.getMessage()+"\n\n"+
                            "name:"+posts.getName()+"\n\n";
                    results.append(data);
                }
            }

            @Override
            public void onFailure(Call<List<Comment>> call, Throwable t) {
                results.setText(t.getMessage());
            }
        });
    }

    private void getDataWRTQueryMap() {
        Map<String,String> parameter = new HashMap<>();
        parameter.put("postId","2");
        parameter.put("_sort","id");
        parameter.put("_order","desc");

        Call<List<Comment>> call = jsonPlaceHolder.getCommentsUsingQueryMap(parameter);

        call.enqueue(new Callback<List<Comment>>() {
            @Override
            public void onResponse(Call<List<Comment>> call, Response<List<Comment>> response) {
                if(!response.isSuccessful()){
                    results.setText("Unable to get the Data");
                }

                List<Comment> pos1 = response.body();

                for(Comment posts: pos1){
                    String data = "";
                    data+="ID: "+posts.getId()+"\n"+
                            "postID: "+posts.getPostId()+"\n"+
                            "Email: "+posts.getEmail()+"\n"+
                            "Message:"+posts.getMessage()+"\n\n"+
                            "name:"+posts.getName()+"\n\n";
                    results.append(data);
                }
            }

            @Override
            public void onFailure(Call<List<Comment>> call, Throwable t) {
                results.setText(t.getMessage());
            }
        });
    }

    public void createPost(){
        Posts posts = new Posts(1,"Microsoft","Good Job");

        Call<Posts> call = jsonPlaceHolder.createPost(posts);
        call.enqueue(new Callback<Posts>() {
            @Override
            public void onResponse(Call<Posts> call, Response<Posts> response) {
                if(!response.isSuccessful()){
                    results.setText("Unable to get the Data");
                }

                Posts posts = response.body();

                String data = "";
                data+= "Code :"+response.code()+"\n"+
                        "ID: "+posts.getId()+"\n"+
                        "UserID: "+posts.getUserId()+"\n"+
                        "Title: "+posts.getTitle()+"\n"+
                        "Message:"+posts.getText()+"\n\n";
                results.append(data);
            }

            @Override
            public void onFailure(Call<Posts> call, Throwable t) {
                results.setText(t.getMessage());
            }
        });
    }

    public void putPost(){
        Posts posts = new Posts(3,"Microsoft12","Good Job");

        Map<String,String> header = new HashMap<>();
        header.put("Auth","Mayur");
        header.put("Token","Mayur123");
        header.put("Time", String.valueOf(new Date().getTime()));

        Call<Posts> call = jsonPlaceHolder.putPost(header,1,posts); // added dynamic headers
        call.enqueue(new Callback<Posts>() {
            @Override
            public void onResponse(Call<Posts> call, Response<Posts> response) {
                if(!response.isSuccessful()){
                    results.setText("Unable to get the Data");
                }

                Posts posts = response.body();

                String data = "";
                data+= "Code :"+response.code()+"\n"+
                        "ID: "+posts.getId()+"\n"+
                        "UserID: "+posts.getUserId()+"\n"+
                        "Title: "+posts.getTitle()+"\n"+
                        "Message:"+posts.getText()+"\n\n";
                results.append(data);
            }

            @Override
            public void onFailure(Call<Posts> call, Throwable t) {
                results.setText(t.getMessage());
            }
        });
    }

    public void patchPost(){
        Posts posts = new Posts(3,null,"Good Job");

        Call<Posts> call = jsonPlaceHolder.patchPost(1,posts);
        call.enqueue(new Callback<Posts>() {
            @Override
            public void onResponse(Call<Posts> call, Response<Posts> response) {
                if(!response.isSuccessful()){
                    results.setText("Unable to get the Data");
                }

                Posts posts = response.body();

                String data = "";
                data+= "Code :"+response.code()+"\n"+
                        "ID: "+posts.getId()+"\n"+
                        "UserID: "+posts.getUserId()+"\n"+
                        "Title: "+posts.getTitle()+"\n"+
                        "Message:"+posts.getText()+"\n\n";
                results.append(data);
            }

            @Override
            public void onFailure(Call<Posts> call, Throwable t) {
                results.setText(t.getMessage());
            }
        });
    }

    public void deletePost(){
        Call<Void> del = jsonPlaceHolder.deletePost(1);

        del.enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
                results.setText("Code: "+response.code());
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                results.setText(t.getMessage());
            }
        });
    }


}